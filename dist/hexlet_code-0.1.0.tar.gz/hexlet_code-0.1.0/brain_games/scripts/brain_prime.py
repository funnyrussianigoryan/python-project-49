#!/usr/bin/env python3
from brain_games import cli
from brain_games.games import brain_prime


def main():
    print('Welcome to the Brain Games!')
    name = cli.welcome_user()
    brain_prime.game(user_name=name)


if __name__ == '__main__':
    main()
