def is_prime(num):
    #need to rewrite all function!!!!
    prime_numbers = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47}
    return num in prime_numbers