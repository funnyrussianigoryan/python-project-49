#!/usr/bin/env python3

GREETING = 'Welcome to the Brain Games!'

def main():
    print(GREETING)

if __name__ == '__main__':
    to_greet()